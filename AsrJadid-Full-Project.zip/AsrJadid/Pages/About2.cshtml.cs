using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class About2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
