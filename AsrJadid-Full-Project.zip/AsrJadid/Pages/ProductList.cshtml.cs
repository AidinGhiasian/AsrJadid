using Microsoft.AspNetCore.Mvc.RazorPages;
using StoneManagement.Application.Contracts.Stone;

namespace AsrJadid.Pages
{
    public class ProductListModel : PageModel
    {
        private readonly IStoneApplication _stoneApplication;

        public ProductListModel(IStoneApplication stoneApplication)
        {
            _stoneApplication = stoneApplication;
        }

        public List<StoneViewModel> Products { get; set; } = new();

        public void OnGet()
        {
            Products = _stoneApplication.GetList();
        }
    }
}
