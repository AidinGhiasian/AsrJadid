using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class BlogGrid2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
