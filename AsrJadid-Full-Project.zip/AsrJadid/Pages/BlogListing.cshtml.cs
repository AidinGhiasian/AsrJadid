using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class BlogListingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
