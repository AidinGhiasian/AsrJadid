using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class BlogGrid4Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
