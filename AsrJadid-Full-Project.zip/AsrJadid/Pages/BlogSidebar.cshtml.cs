using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class BlogSidebarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
