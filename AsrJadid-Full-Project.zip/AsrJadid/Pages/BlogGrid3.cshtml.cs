using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AsrJadid.Pages
{
    public class BlogGrid3Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
