﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneManagement.Application.Contracts.StoneCategory
{
    public class EditViewModel:CreateViewModel
    {
        public long Id { get; set; }
        public string Picture { get; set; }
    }
}
